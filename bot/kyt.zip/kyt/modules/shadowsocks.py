from kyt import *
import requests
import time
import subprocess

import subprocess
import time
import datetime as DT
import re
import asyncio
from telethon import events

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
    user_id = str(event.sender_id)
    chat = event.chat_id  # Get chat ID for conversation

    async def create_shadowsocks_(event):
        try:
            # Ask for the username
            async with bot.conversation(chat) as user_conv:
                await event.respond('**Client Name:**')
                user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
                user = user_msg.raw_text

            # Ask for the expiration days
            async with bot.conversation(chat) as exp_conv:
                await event.respond('**Expiry Date:**')
                exp_msg = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
                exp = exp_msg.raw_text

            # Ask for the allowed IP address (limit)
            async with bot.conversation(chat) as ip_conv:
                await event.respond('**Register Add IP:**')
                ip_msg = await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
                allowed_ip = ip_msg.raw_text

            await event.edit("Processing...")
            await asyncio.sleep(1)
            await event.edit("`Processing berhasil di daftarkan`")
            await asyncio.sleep(1)
            await event.edit("`Wait.. tunggu bentar`")

            # Create the Shadowsocks configuration command, including the IP address restriction
            cmd = f'printf "%s\n" "{user}" "{exp}" "{allowed_ip}" | addss-bot'
            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        # Calculating expiration date
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        
        # Extract ss URL and UUID
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)

        # Formulate the response message
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
    **🟡Scripts by** @RiswanJabar🟡
**━━━━━━━━━━━━━━━━━━━━━━**
**»✅sukses Didaftrakan**
**»👤Client Name:** `{user}`
**»⏲️Expiry Date:** `{later}`
**»🌍IP Address:** `{allowed_ip}`
**━━━━━━━━━━━━━━━━━━━━━━**
`### {user} {later} {allowed_ip}`
**━━━━━━━━━━━━━━━━━━━━━━**
**»🌍UPDATE SC DEBIAN :**
```apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot```
**━━━━━━━━━━━━━━━━━━━━━━**
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🌍UPDATE SC UBUNTU  :**
```apt update && apt upgrade -y && update-grub && sleep 2 && reboot```
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🌍INSTALASI  SCRIPT :** 
```sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update -y && apt upgrade -y && apt install -y bzip2 gzip coreutils screen curl unzip && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/Riswan481/WendyVpn/ABSTRAK/setup-main.sh && chmod +x setup-main.sh && sed -i -e 's/\r$//' setup-main.sh && screen -S setupku ./setup-main.sh```
**━━━━━━━━━━━━━━━━━━━━━━**
`### {user} {later} {allowed_ip}`
**━━━━━━━━━━━━━━━━━━━━━━**
        """
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)









@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
    user_id = str(event.sender_id)
    async def cek_shadowsocks_(event):
        cmd = 'bash cek-mss'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
        
        {z}

**Shows Users Shadowsocks in database**
        """, buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)




@bot.on(events.CallbackQuery(data=b'cek-shadowsocks-online'))
async def cek_shadowsocks(event):
    user_id = str(event.sender_id)
    async def cek_shadowsocks_(event):
        cmd = 'cek-ss'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
** ⟨🔸Cek Scripts User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**        
{z}
 
**Shows online Users Scripts**
        """, buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



















@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
    async def delete_shadowsocks_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_text = (await user_event).raw_text

        cmd = f'printf "%s\n" "{user_text}" | bot-del-ss'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**User Not Found**")
        else:
            msg = "**Successfully Deleted**"
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)







@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
    user_id = str(event.sender_id)
    async def trial_shadowsocks_(event):
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        # ... (other progress edits)
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        try:
            # Assuming this function checks and processes user balance for SSH
            cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" | bot-trialss'
            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(f"Exit code: {e.returncode}")
            print(f"Output: {e.output.decode('utf-8')}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(1))
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)

        msg = f"""
        
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
             **🟡Scripts Premium [JESVPN🟡**
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
**»👤 Nama Clinte:** `{user}`
**»✅ Keterangan Sukses**
**»⏲️ Expired Scripts:** `{today}`
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🌍UPDATE SC DEBIAN :**
```apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot```
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🌍UPDATE SC UBUNTU  :**
```apt update && apt upgrade -y && update-grub && sleep 2 && reboot```
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🌍INSTALASI   :** 
```sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update -y && apt upgrade -y && apt install -y bzip2 gzip coreutils screen curl unzip && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/Riswan481/WendyVpn/ABSTRAK/setup-main.sh && chmod +x setup-main.sh && sed -i -e 's/\r$//' setup-main.sh && screen -S setupku ./setup-main.sh```
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🌍INSTAL UDP masukan perintah**
**ctrl + c enter :** 
```wget https://raw.githubusercontent.com/gemilangvip/autoscript/main/files/udp-custom.sh && chmod +x udp-custom.sh && ./udp-custom.sh```
**◇━━━━━━━━━━━━━━━━━━━━━━━━━━━━◇**
»  🤖@JesVpnt

        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)










@bot.on(events.CallbackQuery(data=b'renew-ss'))
async def ren_ss(event):
    async def ren_ss_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond('**expired days?:**')
            exp = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp.raw_text
            

        cmd = f'printf "%s\n" "{user}" "{exp}" | bot-renew-ss'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**Successfully Renewed  {user} {exp} Days**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await ren_ss_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)







@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
    user_id = str(event.sender_id)

    async def shadowsocks_(event):
        inline = [
            
             [Button.inline("Regis ip", "create-shadowsocks")],
             
            [Button.inline("Back menu", "menu")]]
        
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸SCRIPTS MANAGER🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
» Service: `SCRIPTS`
» Hostname/IP: `{DOMAIN}`
» ISP: `{z["isp"]}`
» Country: `{z["country"]}`
**» ** 🤖@JesVpnt
**◇━━━━━━━━━━━━━━━━━◇**
"""

        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


